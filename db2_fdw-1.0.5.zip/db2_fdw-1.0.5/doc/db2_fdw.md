db2_fdw
=======

Synopsis
--------

  The db2_fdw is the foreign data wrapper of PostgreSQL
  to access a DB2 database.

Description
-----------

Based on the foreign data wrapper of postgreSQL to oracle, the db2_fdw was built.
Main difference are the data types. They are mainly not standardized. So therefore some parts are still under development.

Usage
-----

  Show usage.

Support
-------

    [GitHub Link to db2_fdw](https://github.com/wolfgangbrandl/db2_fdw)

    [email](wolfgang.brandl@brz.gv.at)

Author
------

[Ing. Wolfgang Brandl](wolfgang.brandl@brz.gv.at)

Copyright and License
---------------------

Copyright (c) 2018 Ing Wolfgang Brandl.
